import {slowCypressDown} from 'cypress-slow-down'
slowCypressDown(300)

describe('CLUMS Routes Test', () => {
    it('GET users route', () => {
      cy.visit('http://127.0.0.1:8000/docs#/Users/get_students_api_student__get')
      cy.request('http://127.0.0.1:8000/api/student/').then((response)=>{
  expect(response.status).to.eq(200)
  expect(response.body).to.have.length.above(0)
      })
  
  })
 
it('GET users route', () => {
    cy.visit('http://127.0.0.1:8000/docs#/Users/get_teacher_api_teacher__get')
    cy.request('http://127.0.0.1:8000/api/teacher/').then((response)=>{
expect(response.status).to.eq(200)
expect(response.body).to.have.length.above(0)
  })
})
it('GET users route', () => {
    cy.visit('http://127.0.0.1:8000/docs#/Users/get_enrollment_api_enrollment__get')
    cy.request('http://127.0.0.1:8000/api/enrollment/').then((response)=>{
expect(response.status).to.eq(200)
expect(response.body).to.have.length.above(0)
  })
})
it('GET users route', () => {
    cy.visit('http://127.0.0.1:8000/docs#/Users/get_subjects_api_subject__get')
    cy.request('http://127.0.0.1:8000/api/subject/').then((response)=>{
expect(response.status).to.eq(200)
expect(response.body).to.have.length.above(0)
  })
})
it('GET users route', () => {
    cy.visit('http://127.0.0.1:8000/docs#/Users/get_report_api_report__get')
    cy.request('http://127.0.0.1:8000/api/report/').then((response)=>{
expect(response.status).to.eq(200)
expect(response.body).to.have.length.above(0)
  })
})

})

//describe('Create Account Type Endpoint', () => {
  it('Should create a new account type', () => {
      cy.visit('http://127.0.0.1:8000/docs#/Users/login_administrator_api_student_login__post')
      // Define the payload for the POST request
      const payload = {
          AccountType: 'New Account Type'
      };

      // Send a POST request to the endpoint
      cy.request({
          method: 'POST',
          url: 'http://127.0.0.1:8000/api/student/login/',
          form: true, // Indicate that the request body is form-encoded
          body: payload
      }).then((response) => {
          // Assert that the request was successful (status code 2xx)
          expect(response.status).to.be.oneOf([200, 201]);

          // Assert that the response contains the expected account type
          expect(response.body).to.deep.include(payload);
      });
  });
//});

/*describe('Update Account Type API', () => {
  it('successfully updates an account type', () => {
      cy.visit('http://127.0.0.1:8000/docs#/account_types/read_account_types_api_account_types__get')
    cy.request({
      method: 'PUT',
      url: 'http://127.0.0.1:8000/api/account_types/2',
      body: {
        AccountType: 'Admin'
      },
      failOnStatusCode: false // Prevent Cypress from failing the test due to non-2xx or 3xx status codes
    }).then((response) => {
      if (response.status === 422) {
        // Validation error
        cy.log('Validation error:', response.body.detail);
        // Expecting a validation error, not failing the test
      } else {
        // Successful response
        expect(response.status).to.eq(200);
        expect(response.body).to.deep.eq({
          AccountTypeID: 2,
          AccountType: 'Admin'
        });
      }
    });
  });
});*/
/*describe('CLUMS Routes Test', () => {
  it('POST users route', () => {
    cy.visit('http://127.0.0.1:8000/docs#/Users/get_students_api_student__get')
    cy.request('http://127.0.0.1:8000/api/student/').then((response)=>{
expect(response.status).to.eq(200)
expect(response.body).to.have.length.above(0)
    })
  })
})*/

  
describe('POST Route', () => {
  it('Post route be approved', () => {
    cy.visit('http://127.0.0.1:8000/docs#/Users/login_administrator_api_student_login__post');
    cy.get('.btn').should('be.visible').click()
    cy.get('[data-property-name="username"] > .parameters-col_description > div > input').should('be.visible').type('admin123').wait(500);
    cy.get('[data-property-name="password"] > .parameters-col_description > div > input').should('be.visible').type('123admin').wait(500);
   cy.get('.execute-wrapper > .btn').should('be.visible').click().wait(500);

  })
});

