import {slowCypressDown} from 'cypress-slow-down'
slowCypressDown(700)

describe('Users Routes Test', () => {
    it('GET users route', () => {
      cy.visit('http://127.0.0.1:8000/docs#/Users/get_students_api_student__get')
      cy.request('http://127.0.0.1:8000/api/student/')
  
  })
 
it('GET users route', () => {
    cy.visit('http://127.0.0.1:8000/docs#/Users/get_teacher_api_teacher__get')
    cy.request('http://127.0.0.1:8000/api/teacher/')
})
it('GET users route', () => {
    cy.visit('http://127.0.0.1:8000/docs#/Users/get_enrollment_api_enrollment__get')
    cy.request('http://127.0.0.1:8000/api/enrollment/')
})
it('GET users route', () => {
    cy.visit('http://127.0.0.1:8000/docs#/Users/get_subjects_api_subject__get')
    cy.request('http://127.0.0.1:8000/api/subject/')
})
it('GET users route', () => {
    cy.visit('http://127.0.0.1:8000/docs#/Users/get_report_api_report__get')
    cy.request('http://127.0.0.1:8000/api/report/')
})

  

    it('Post login route be approved', () => {
      cy.visit('http://127.0.0.1:8000/docs#/Users/login_administrator_api_student_login__post');
      cy.get('.btn').should('be.visible').click()
      cy.get('[data-property-name="username"] > .parameters-col_description > div > input').should('be.visible').type('admin123');
      cy.get('[data-property-name="password"] > .parameters-col_description > div > input').should('be.visible').type('123admin');
     cy.get('.execute-wrapper > .btn').should('be.visible').click();
  
    })
 


    it('Post sign in route be approved', () => {
      cy.visit('http://127.0.0.1:8000/docs#/Users/create_administrator_api_users_create_post');
      cy.get('.btn').should('be.visible').click()
      cy.get('[data-property-name="username"] > .parameters-col_description > div > input').should('be.visible').type('Marc');
      cy.get('[data-property-name="password"] > .parameters-col_description > div > input').should('be.visible').type('Costillas123');
     cy.get('.execute-wrapper > .btn').should('be.visible').click();
  
    })
    it('Delete users route approved', () => {
        cy.visit('http://127.0.0.1:8000/docs#/Users/delete_user_api_users__user_id__delete');
        cy.get('.btn').should('be.visible').click()
        cy.get('input').should('be.visible').type('22001272');
       cy.get('.execute-wrapper > .btn').should('be.visible').click();
    
      })
})

describe('Report Routes Test', () => {
    it('GET report route', () => {
      cy.visit('http://127.0.0.1:8000/docs#/report/get_report_api_report__get')
      cy.request('http://127.0.0.1:8000/api/report/')
  })

  it('Post create report route be approved', () => {
    cy.visit('http://127.0.0.1:8000/docs#/report/create_report_api_report_create_post');
    cy.get('.btn').should('be.visible').click()
    cy.get('[data-property-name="student_id"] > .parameters-col_description > div > input').should('be.visible').type('22001273');
    cy.get('[data-property-name="issue"] > .parameters-col_description > div > input').should('be.visible').type('The Monitor is broken');
    cy.get('[data-property-name="unit_number"] > .parameters-col_description > div > input').should('be.visible').type('10');
   cy.get('.execute-wrapper > .btn').should('be.visible').click();

  })
  it('Get report id report route approved', () => {
    cy.visit('http://127.0.0.1:8000/docs#/report/delete_report_api_report__report_id__delete');
    cy.get('.btn').should('be.visible').click()
    cy.get('input').should('be.visible').type('9');
   cy.get('.execute-wrapper > .btn').should('be.visible').click();

  })
  /*it('Delete report route approved', () => {
    cy.visit('http://127.0.0.1:8000/docs#/report/delete_report_api_report__report_id__delete');
    cy.get('.btn').should('be.visible').click()
    cy.get('input').should('be.visible').type('22001272');
   cy.get('.execute-wrapper > .btn').should('be.visible').click();

  })*/

})

 