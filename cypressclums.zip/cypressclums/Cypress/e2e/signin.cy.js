
  
describe('sign up page', () => {
    it('should sign up with correct credentials', () => {
      cy.visit('http://localhost:5173/');
      cy.get('[href="/register"] > a').should('be.visible').click();
      cy.get('#username').should('be.visible').type('admin123');
     cy.get('#password').should('be.visible').type('123admin');
     cy.get('#confirmpass').should('be.visible').type('123admin');
     cy.get('button').should('be.visible').click();
  
    })
  
  
  });
  describe('login page', () => {
    it('should login with correct credentials', () => {
      cy.visit('http://localhost:5173/');
      cy.get('[type="text"]').should('be.visible').type('admin123');
      cy.get('[type="password"]').should('be.visible').type('123admin');
     cy.get('button').should('be.visible').click();
  
    })
  });