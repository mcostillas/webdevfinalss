
  
describe('login page', () => {
    it('should login with correct credentials', () => {
      cy.visit('http://localhost:5173/');
      cy.get('[type="text"]').should('be.visible').type('ear');
      cy.get('[type="password"]').should('be.visible').type('11');
     cy.get('button').should('be.visible').click();
  
    })
  });

 